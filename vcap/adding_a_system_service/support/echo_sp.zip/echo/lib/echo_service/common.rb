# Copyright (c) 2009-2011 VMware, Inc.
module VCAP
  module Services
    module Echo
      module Common
        def service_name
          "EchoaaS"
        end
      end
    end
  end
end
