package org.cloudfoundry.webapps.echo;

public class ServiceParserException  extends Exception{

	private static final long serialVersionUID = 1L;

	public ServiceParserException(String message) {
		super(message);
	}
}
