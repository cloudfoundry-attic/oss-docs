package org.cloudfoundry.webapps.echo;

public class EchoServiceCreds {
	private String host;
	private int port;
	private String name;

	public String getHost() {
		return host;
	}

	public int getPort() {
		return port;
	}

	public String getName() {
		return name;
	}

	public EchoServiceCreds(String name, int port, String host) {
		this.host = host;
		this.port = port;
		this.name = name;
	}
}
